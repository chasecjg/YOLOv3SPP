import torch

data = torch.rand((9,2))
print(data)
print(data[0])